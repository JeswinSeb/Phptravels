package com.qa.phptravels.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class AdminLogin {
WebDriver driver;
		
	@FindBy(xpath="//a[text()='Customer Login']")
	private WebElement CusLog;
	
	@FindBy(xpath="//input[@name='email'][@placeholder=' ']")
	private WebElement Email;
	
	@FindBy(xpath="//input[@name='password'][@placeholder=' ']")
	private WebElement Password;
	
	@FindBy(xpath="//button[@class='btn btn-primary btn-block ladda-button fadeIn animated mdc-ripple-upgraded']")
	private WebElement AdminSubmit;
	
	@FindBy(xpath="//h1[@class='display-4 mb-0']")
	private static  WebElement Dashboard;
	@FindBy(xpath="//div[@class='resultlogin']")
	private static  WebElement 	ResultLogin;
	
	@FindBy(xpath="//button[@id='dropdownMenuProfile']")
	private WebElement Profile;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/api/admin/logout']")
	private WebElement logout;
	
	@FindBy(xpath="//a[@data-bs-target='#ForgetPassword']")
	private WebElement Signup;
	

	@FindBy(xpath="//input[@id='resetemail']")
	private static WebElement Resetpass;
	
	
	@FindBy(xpath="//a[@href='https://phptravels.net/api/admin/bookings'][@class='nav-link loadeffect']")
	private static WebElement Booking;
	
	@FindBy(xpath="(//select[@id='payment_status'][@class='form-select status paid'])[1]")
	private static WebElement Paymentstatus;
	
	@FindBy(xpath="(//select[@id='booking_status'][@class='form-select status pending'])[1]")
	private static WebElement Bookingstatus;
	
	@FindBy(xpath="(//a[@class='btn btn-outline-dark mdc-ripple-upgraded'])[2]")
	private static WebElement invoice;
	
	@FindBy(xpath="(//div[@class='display-5'])[2]")
	private static WebElement Pending_First;
	
	@FindBy(xpath="(//div[@class='display-5'])[1]")
	private static WebElement Confirm_First;
	
	@FindBy(xpath="(//div[@class='display-5'])[2]")
	private static WebElement Pending_Second;
	
	@FindBy(xpath="(//div[@class='display-5'])[1]")
	private static WebElement Confirm_Second;
	
	
	@FindBy(xpath="(//a[@class='nav-link'])[1]")
	private static WebElement website;
	
	@FindBy(xpath="(//div[@class='display-5'])[3]")
	private WebElement cancelcount1;
	

	@FindBy(xpath="(//div[@class='display-5'])[3]")
	private WebElement cancelcount2;
	
	//@FindBy(xpath="//select[@id='payment_status']")
//	private static WebElement[] payStat;
	
	//@FindBy(xpath="(//a[@class='btn btn-outline-dark mdc-ripple-upgraded'])")
			//private static WebElement[] DisplayVoucher;
	
	public AdminLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
		
	public void clickCusLog() {
		CusLog.click();
	}
	public void enterEmail(String strEmail) {
		Email.sendKeys(strEmail); 
	}
	public void enterPass(String strPass) {
		Password.sendKeys(strPass);
	}
	public void AdminSubmit() {
		AdminSubmit.click();
	}
	
	public static boolean checkDash() {
		boolean test=Dashboard.isDisplayed();
		return test;
	}
	public static boolean checkResult() {
		boolean test1=ResultLogin.isDisplayed();
		return test1;
	}
	
	public void clickProfile() {
		Profile.click();
	}
	public void clickLogout() {
		logout.click();
	}
	public void ClickSignup() {
		Signup.click();
	}
	public static boolean CheckSignup() {
		boolean RPass=Resetpass.isDisplayed();
		return RPass;
	}
	public void ClickBooking() {
		Booking.click();
	}
	
	public void ClickInvoice() {
		invoice.click();
	}
	public String checkPayment() {
		 Select select = new Select(driver.findElement(By.xpath("(//select[@id='payment_status'][@class='form-select status paid'])[1]")));

		 WebElement option = select.getFirstSelectedOption();

		 String status = option.getText();
		
		 
		 //System.out.println(status);
		 return status;
		
	}
	public void changeStatus() {
		Select dropdown = new Select(Bookingstatus);  
		 dropdown.selectByVisibleText("Confirmed");
		WebElement sss = dropdown.getFirstSelectedOption();
		String ssss=sss.getAttribute("class");
		///System.out.println(ssss);
	}
	public String checkConf1() {
		String Conf_Count1=Confirm_First.getText();
		
		System.out.println(Conf_Count1);
		//System.out.println(Pend_Count1);
		return Conf_Count1;
		
	}
	public String checkPend1() {
		String Pend_Count1=Pending_First.getText();
		return Pend_Count1;
	}
	public String checkConf2() {
		String Conf_Count2=Confirm_Second.getText();
		return Conf_Count2;
		
	}
	public String checkPend2() {
		String Pend_Count2=Pending_Second.getText();
		return Pend_Count2;
	}
	public void clickwebsite() {
		website.click();
	}
	public String rowNom(String value)
	{
	   WebElement table =driver.findElement(By.xpath("//table[@id='data']"));
	   WebElement tbody=table.findElement(By.tagName("tbody"));
	   List<WebElement> rows=tbody.findElements(By.tagName("tr"));
	   ArrayList<String> ListOdIds=new ArrayList<String>();
	   String rowNo="";
	   for(int i=0;i<rows.size();i++)
	   {
	     WebElement row = tbody.findElement(By.xpath("//table[@id='data']/tbody/tr["+(i+1)+"]"));
	     if(row.getText().trim().contains(value))
	     {
	        rowNo=Integer.toString(i+1); 
	            break;
	     }

	   }

	   return rowNo;
	}
	
	public void Checkinvoice() throws InterruptedException {
		
		for(int i=1;i<=10;i++) {
			String arr="";
			//WebElement payStat=driver.findElement(By.xpath("(//select[@id='payment_status'])["+i+"]"));
			Select select = (Select) new Select(driver.findElement(By.xpath("(//select[@id='payment_status'])["+i+"]")));

			 WebElement option = select.getFirstSelectedOption();
			 //System.out.println(option.getText());
			arr=option.getText().toString();
			String paid="PAID";
			
			
			if(arr.equals(paid)) 
			{
			System.out.println(i);
			driver.findElement(By.xpath("(//a[@class='btn btn-outline-dark mdc-ripple-upgraded'])["+i+"]")).click();
			//System.out.println(option.getText());
			Thread.sleep(3000);
			break;
			
			}
		}
	}
		public void DeleteCancel() throws InterruptedException {
			
			for(int i=1;i<=10;i++) {
				String Status="";
				//WebElement payStat=driver.findElement(By.xpath("(//select[@id='payment_status'])["+i+"]"));
				Select select = (Select) new Select(driver.findElement(By.xpath("(//select[@id='booking_status'])["+i+"]")));

				 WebElement option = select.getFirstSelectedOption();
				 //System.out.println(option.getText());
				Status=option.getText().toString();
				String Text="CANCELLED";
				
				
				if(Status.equals(Text)) 
				{
				//System.out.println(i);
				driver.findElement(By.xpath("(//button[@class='btn btn-danger mdc-ripple-upgraded'])["+i+"]")).click();
				//System.out.println(option.getText());
				Thread.sleep(3000);
				break;
				
				}
			}

		}
		public String checkcancel1() {
			String CanCount1=cancelcount1.getText();
			
			return CanCount1;
			
		}
		public String checkcancel2() {
			String CanCount2=cancelcount2.getText();
			
			return CanCount2;
			
		}
}

