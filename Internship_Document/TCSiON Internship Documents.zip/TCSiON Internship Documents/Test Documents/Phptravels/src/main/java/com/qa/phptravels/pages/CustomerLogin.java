package com.qa.phptravels.pages;
import org.apache.xmlbeans.impl.xb.xsdschema.ListDocument.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CustomerLogin {
	WebDriver driver;
	
	@FindBy(xpath="//button[@id='ACCOUNT']")
	private WebElement Account;
	
	@FindBy(xpath="//a[text()='Customer Login']")
	private WebElement CusLog;
	
	@FindBy(xpath="//input[@placeholder='Email']")
	private WebElement Email;
	
	@FindBy(xpath="//input[@name='password']")
	private WebElement Password;
	
	@FindBy(xpath="//button[@class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']")
	private WebElement CusSubmit;
	
	@FindBy(xpath="//a[@class='btn-lg d-flex align-items-center justify-content-center  btn btn-outline-primary btn-block form-group effect ladda-sm ladda-button waves-effect']")
	private WebElement Signup;
	@FindBy(xpath="//button[@class=\"btn btn-primary dropdown-toggle waves-effect\"]")
	private WebElement Account2;
	@FindBy(xpath="//a[text()=' Logout']")
	private WebElement logout;
	@FindBy(xpath="//label[@data-bs-target='#reset']")
	private WebElement Reset;
	@FindBy(xpath="//form[@action='https://phptravels.net/reset_password']")
	private WebElement ResetBox;
	@FindBy(xpath="//a[@href='https://phptravels.net/'][@class=' waves-effect']")
	private WebElement Home;
	
	@FindBy(xpath="(//a[@href='https://phptravels.net/account/bookings'])[1]")
	private WebElement Bookings;
	
	@FindBy(xpath="(//a[@href='https://phptravels.net/account/add_funds'])[1]")
	private WebElement AddFunds;
	
	@FindBy(xpath="(//a[@href='https://phptravels.net/account/profile'])[1]")
	private WebElement MyProfile;
	
	@FindBy(xpath="//a[@class='theme-btn theme-btn-small waves-effect'][1]")
	private WebElement Voucher;
	
	@FindBy(xpath="//input[@name='firstname']")
	private WebElement firstname;
	
	@FindBy(xpath="//input[@name='lastname']")
	private WebElement lastname;
	
	@FindBy(xpath="//input[@name='phone']")
	private WebElement phone;
	
	@FindBy(xpath="//input[@name='email']")
	private WebElement ProEmail;
	
	@FindBy(xpath="//input[@name='password']")
	private WebElement ProPassword;
	
	@FindBy(xpath="//select[@name='country']")
	private WebElement country;
	
//	@FindBy(xpath="//span[@title='India']")
	//private WebElement country_name;
	
	@FindBy(xpath="//input[@name='state']")
	private WebElement state;
	
	@FindBy(xpath="//input[@name='city']")
	private WebElement city;
	
	@FindBy(xpath="//input[@name='fax']")
	private WebElement fax;
	
	@FindBy(xpath="//input[@name='zip']")
	private WebElement postalcode;
	
	@FindBy(xpath="//input[@name='address1']")
	private WebElement address1;
	
	@FindBy(xpath="//input[@name='address2']")
	private WebElement address2;
	
	@FindBy(xpath="//button[text()='Update Profile']")
	private WebElement updateprofile;
	
	@FindBy(xpath="(//input[@name='payment_gateway'])[3]")
	private WebElement Paypal;
	
	@FindBy(xpath="//input[@name='price']")
	private WebElement price;
	
	@FindBy(xpath="//button[text()='Pay Now ']")
	private WebElement PayNow;
	
	@FindBy(xpath="(//div[@aria-label='PayPal'])[1]")
	private WebElement MoveToPaypal;
	
	@FindBy(xpath="//div[@class='btn-front']")
	private WebElement MoveBack;
	
	@FindBy(xpath="(//a[@class='yes']']")
	private WebElement MoveBackYes;
	 	
	
	@FindBy(xpath="//button[@class='btn-close waves-effect']")
	private WebElement Close;
	
	@FindBy(xpath="//button[@id='languages']")
	private WebElement Language;
	
	@FindBy(xpath="//a[text()=' English']")
	private WebElement English;
	
	public void ClickAcc() {
		Account2.click();
	}
	public void ClickClose() {
		Close.click();
	}
	public void clickLogout() {
		logout.click();
	}
	
	public CustomerLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickAccount() {
		Account.click();
	}
	public void clickCusLog() {
		CusLog.click();
	}
	
	public void enterEmail(String strEmail) {
		Email.clear();
		Email.sendKeys(strEmail);
	}
	public void enterPass(String strPass) {
		Password.clear();
		Password.sendKeys(strPass);
	}
	public void CustomerSubmit() {
		CusSubmit.click();
	}

	public void ClickSignup() {
		Signup.click();
	}
	public void ClickReset() {
		Reset.click();
	}
	public void ClickHome() {
		Home.click();
	}
	public void ClickBookings() {
		Bookings.click();
	}
	public void ClickFunds() {
		AddFunds.click();
	}
	public void ClickProfile() {
		MyProfile.click();
	}
	public void ClickVoucher() {
		Voucher.click();
	}
	
	public void setFirst(String first_name) {
		firstname.clear();
		firstname.sendKeys(first_name);
	}
	
	public void SetLast(String last_name) {
		lastname.clear();
		lastname.sendKeys(last_name);
	}
	public void SetPhone(String phone_num) {
		phone.clear();
		phone.sendKeys(phone_num);
	}
	
	public void SetProEmail(String P_email) {
		ProEmail.clear();
		ProEmail.sendKeys(P_email);
	}
	public void SetPassword(String Pro_password) {
		ProPassword.clear();
		ProPassword.sendKeys(Pro_password);
	}
	public void SetCountry(String cntr) {
		Select dropdown = new Select(country);  
		dropdown.selectByValue(cntr);
	}
	/*public void SetCountry() {
		country.click();
	}*/
	public void SetState(String stat) {
		state.clear();
		state.sendKeys(stat);
	}
	public void SetCity(String cit) {
		city.clear();
		city.sendKeys(cit);
	}
	public void SetFax(String Fax_num) {
		fax.clear();
		fax.sendKeys(Fax_num);
	}
	public void SetPostal(String zip) {
		postalcode.clear();
		postalcode.sendKeys(zip);
	}
	public void SetAddress1(String add1) {
		address1.clear();
		address1.sendKeys(add1);
	}
	public void SetAddress2(String add2) {
		address2.clear();
		address2.sendKeys(add2);
	}
	public void UpdateProfile() {
		updateprofile.click();
	}
	boolean box;
	public boolean CheckReset() {
		if(ResetBox.isDisplayed()) {
			box=true;
		}
		else
		{
			box=false;
		}
		return box;
	}
	
	public void ClickPaypal() {
		
		//driver.findElement(By.xpath("//button[@id='cookie_stop']")).click();
		if(!Paypal.isSelected()) {
			Paypal.click();
		}
		
	}
	public void cookie() {
		if(driver.findElement(By.xpath("//button[@id='cookie_stop']")).isDisplayed()) {
			driver.findElement(By.xpath("//button[@id='cookie_stop']")).click();
		}
	}
	public void SendFund() {
		price.clear();
		price.sendKeys("50");
	}
	public void ClickPayNow() {
		PayNow.click();
	}
	public void MoveToPay() {
		MoveToPaypal.click();
	}
	public void SetLanguage() {
		Language.click();
		
	}
	public void SetEnglish() {
		English.click();
	}
	public void Moveback()
	{
		MoveBack.click();
		MoveBackYes.click();
	}
	 
}
