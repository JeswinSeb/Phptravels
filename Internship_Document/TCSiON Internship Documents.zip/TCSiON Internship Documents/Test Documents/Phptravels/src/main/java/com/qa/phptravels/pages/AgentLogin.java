package com.qa.phptravels.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class AgentLogin {

WebDriver driver;
	
	@FindBy(xpath="//button[@id='ACCOUNT']")
	private WebElement Account;

	@FindBy(xpath="//a[text()='Customer Login']")
	private WebElement CusLog;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/bookings']")
	private WebElement Bookings;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/add_funds']")
	private WebElement AddFunds;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/profile']")
	private WebElement MyProfile;
	
	@FindBy(xpath="//*[@id=\"fadein\"]/div[4]/div/div[2]/div[2]/div/form/div[1]/div/input")
	private WebElement Email;
	
	@FindBy(xpath="//input[@name='password']")
	private WebElement Password;
	
	@FindBy(xpath="//button[@class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']")
	private WebElement AgSubmit;
	
	@FindBy(xpath="//a[@class='btn-lg d-flex align-items-center justify-content-center  btn btn-outline-primary btn-block form-group effect ladda-sm ladda-button waves-effect']")
	private WebElement Signup;
	
	@FindBy(xpath="//button[@class=\"btn btn-primary dropdown-toggle waves-effect\"]")
	private WebElement Account2;
	
	@FindBy(xpath="//a[text()=' Logout']")
	private WebElement logout;
	
	@FindBy(xpath="//label[@data-bs-target='#reset']")
	private WebElement Reset;
	
	@FindBy(xpath="//form[@action='https://phptravels.net/reset_password']")
	private WebElement ResetBox;
	
	@FindBy(xpath="//a[@class=' waves-effect'][@href='https://phptravels.net/']")
	private WebElement home;
	
	@FindBy(xpath="//a[@title='hotels']")
	private WebElement hotels;
	
	@FindBy(xpath="//a[@title='flights']")
	private WebElement flights;
	
	@FindBy(xpath="//a[@title='tours']")
	private WebElement tours;
	
	@FindBy(xpath="//a[@title='visa']")
	private WebElement visa;
	
	@FindBy(xpath="//a[@title='blog']")
	private WebElement blog;
	
	@FindBy(xpath="//a[@title='offers']")
	private WebElement offers;
	
	@FindBy(xpath="//select[@id='hotels_city']")
	private WebElement location;
	
	@FindBy(xpath="//input[@class='select2-search__field']")
	private WebElement loc;
	
	@FindBy(xpath="//button[@id='submit']")
	private WebElement Search;
	
	@FindBy(xpath="//button[@id='currency']")
	private WebElement currency;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/currency-INR']")
	private WebElement INR;
	
	public void ClickHome() {
		home.click();
	}
	
	public void ClickHotel() {
		hotels.click();
	}
	
	public void ClickFlights() {
		flights.click();
	}
	
	public void ClickTours() {
		tours.click();
	}
	
	public void ClickVisa() {
		visa.click();
	}
	
	public void ClickBlog() {
		blog.click();
	}
	
	public void ClickOffers() {
		offers.click();
	}

	public void ClickBookings() {
		Bookings.click();
	}
	public void ClickFunds() {
		AddFunds.click();
	}
	public void ClickProfile() {
		MyProfile.click();
	}
	public void clickAccount() {
		Account.click();
	}
	public void clickCusLog() {
		CusLog.click();
	}
	
	public void ClickAcc() {
		Account2.click();
	}
	public void clickLogout() {
		logout.click();
	}
	
	public AgentLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	
	public void enterEmail(String strEmail) {
		Email.sendKeys(strEmail);
	}
	public void enterPass(String strPass) {
		Password.sendKeys(strPass);
	}
	public void AgentSubmit() {
		AgSubmit.click();
	}
	public void search_hotel() {
		loc.click();
	loc.sendKeys("dub");
	}
	public void  SearchHotel(String loc) {
		
		Select dropdown = new Select(location);
		dropdown.selectByValue(loc);
	}
	
	public void search()
	{
		Search.click();
		
	}
	public void ClickCurrency()
	{
		currency.click();
		
	}
	public void ClickINR()
	{
		INR.click();
		
	}
	public void ClickSignup() {
		Signup.click();
	}
	public void ClickReset() {
		Reset.click();
	}
	boolean inr;
	public String checkINR() {
		String str=currency.getText();
		//return inr;
		return str;
		
	}
	boolean box;
	public boolean CheckReset() {
		if(ResetBox.isDisplayed()) {
			box=true;
		}
		else
		{
			box=false;
		}
		return box;
	}
	
}
