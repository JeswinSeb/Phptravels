package com.qa.phptravels.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SupplierLogin {
	WebDriver driver;
	
	@FindBy(xpath="//a[text()='Customer Login']")
	private WebElement CusLog;
	
	@FindBy(xpath="//input[@name='email'][@placeholder=' ']")
	private WebElement Email;
	
	@FindBy(xpath="//input[@name='password'][@placeholder=' ']")
	private WebElement Password;
	
	@FindBy(xpath="//button[@class='btn btn-primary btn-block ladda-button fadeIn animated mdc-ripple-upgraded']")
	private WebElement SuppSubmit;
	
	@FindBy(xpath="//h1[@class='display-4 mb-0']")
	private static  WebElement Dashboard;
	
	@FindBy(xpath="//div[@class='resultlogin']")
	private static  WebElement 	ResultLogin;
	
	@FindBy(xpath="//button[@id='dropdownMenuProfile']")
	private WebElement Profile;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/api/supplier/logout']")
	private WebElement logout;
	
	@FindBy(xpath="//a[@id='link-forgot']")
	private WebElement Forget;
	

	@FindBy(xpath="//input[@id='resetemail']")
	private static WebElement Resetpass;
	

	@FindBy(xpath="//div[text()='Dashboard']")
	private static WebElement DashBoard;
	
	@FindBy(xpath="//div[text()='Sales overview & summary']")
	private static WebElement Text;
	
	
	@FindBy(xpath="//canvas[@id='dashboardBarChart']")
	private static WebElement Revenew_BreakDOwn;
	
	@FindBy(xpath="(//a[@href='https://phptravels.net/api/supplier/bookings'])[2]")
	private static WebElement Booking;
	
	
	public SupplierLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
		
	public void clickCusLog() {
		CusLog.click();
	}
	public void enterEmail(String strEmail) {
		Email.sendKeys(strEmail); 
	}
	public void enterPass(String strPass) {
		Password.sendKeys(strPass);
	}
	public void SupplierSubmit() {
		SuppSubmit.click();
	}
	
	public static boolean checkDash() {
		boolean test=DashBoard.isDisplayed();
		return test;
	}
	public static boolean checkResult() {
		boolean test1=ResultLogin.isDisplayed();
		return test1;
	}
	
	public void clickProfile() {
		Profile.click();
	}
	public void clickLogout() {
		logout.click();
	}
	public void ClickForget() {
		Forget.click();
	}
	public static boolean CheckSignup() {
		boolean RPass=Resetpass.isDisplayed();
		return RPass;
	}
	
	public static boolean checkDashBoard() {
		boolean test1=DashBoard.isDisplayed();
		return test1;
	}
	public static boolean checkText() {
		boolean test=Text.isDisplayed();
		return test;
	}
	public boolean CheckRevBrkDwn() {
		boolean RevBrDwn= Revenew_BreakDOwn.isDisplayed();
		return RevBrDwn;
	}
	public void clickBooking() {
		Booking.click();
	}
	
	public String CheckBooking() {
		String Title=driver.getTitle();
		System.out.println(Title);
		return Title;
	}
	
}
