package com.qa.phptravels.testscripts;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.qa.phptravels.pages.AdminLogin;
import com.qa.phptravels.utilities.ExcelUtility;

public class Testclass2 extends Testbase2{
	
	AdminLogin Adlogin;
	
	@Test(priority=1,description="Verify Admin can login with valid email and password")

	public void AdminLoginverification01() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		
		if(AdminLogin.checkDash()==true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
	Adlogin.clickProfile();
	Thread.sleep(1000);
	Adlogin.clickLogout();
	Thread.sleep(3000);
	}
	
	@Test(priority=2,description="Verify Admin cannot login with valid email and invalid password")

	public void AdminLoginverification02() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		
		String Logemail = ExcelUtility.getCellData(1, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = ExcelUtility.getCellData(1, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		boolean check=AdminLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=3,description="Verify Admin cannot login with invalid email and valid password")

	public void AdminLoginverification03() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		driver.navigate().refresh();
		
		String Logemail = ExcelUtility.getCellData(2, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = ExcelUtility.getCellData(2, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		boolean check=AdminLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}

	@Test(priority=4,description="Verify Admin cannot login with invalid email and invalid password")

	public void AdminLoginverification04() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		
		driver.navigate().refresh();
		
		String Logemail = ExcelUtility.getCellData(3, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = ExcelUtility.getCellData(3, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		
		boolean check=AdminLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=5,description="Verify Admin cannot login with valid email and null password")

	public void AdminLoginverification05() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		
		driver.navigate().refresh();
		
		String Logemail = ExcelUtility.getCellData(1, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = ""; //ExcelUtility.getCellData(1, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		
		boolean check=AdminLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=6,description="Verify Admin cannot login with null email and valid password")

	public void AdminLoginverification06() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		
		driver.navigate().refresh();
		
		String Logemail = ""; //ExcelUtility.getCellData(5, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = ExcelUtility.getCellData(5, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);
				boolean check=AdminLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=7,description="Verify Admin cannot login with null email and null password")

	public void AdminLoginverification07() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		
		driver.navigate().refresh();
		
		String Logemail = ""; // ExcelUtility.getCellData(1, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = "";  //ExcelUtility.getCellData(1, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		
		boolean check=AdminLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=8,description="Verify Admin can reset password using the forget password link, admin should get a popup message with a textbox to type the email associated with the account to sent the password reset link")

	public void AdminLoginverification08() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		driver.navigate().refresh();
		
		Adlogin.ClickSignup();
		Boolean ResetPassword=Adlogin.CheckSignup();
		if(ResetPassword=true) {
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		
	}
	
	@Test(priority=9,description="Verify Admin can move to booking page using the bookings link and admin can see the invoice of the booking which is marked as confirmed confirmed")

	public void AdminBookingVoucher() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);
		Adlogin.ClickBooking();
		Thread.sleep(1000);

		Adlogin.Checkinvoice();
		 ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs.get(1));
		Thread.sleep(1000);
		String link=driver.getCurrentUrl();
		boolean chck=link.contains("invoice");
		Assert.assertTrue(chck);
		
		
		
	}
	
	@Test(priority=10,description="Verify Admin can change the booking status from pending to confirmed and verify the counts.")

	public void AdminChangeStatus() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);
		Adlogin.ClickBooking();
		Thread.sleep(1000);
		String Con1=Adlogin.checkConf1();
		int Conf1=Integer.parseInt(Con1);
		String Pen1=Adlogin.checkPend1();
		int Pend1=Integer.parseInt(Pen1);
		Adlogin.changeStatus();
		Thread.sleep(1000);
		String Con2=Adlogin.checkConf2();
		int Conf2=Integer.parseInt(Con2);
		String Pen2=Adlogin.checkPend2();
		int Pend2=Integer.parseInt(Pen2);
		
		if(Conf2==Conf1+1 && Pend2==Pend1-1) {
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		
	}
	
	@Test(priority=11,description="Verify Admin can can move to different pages using the website link in customer dashboard")
	public void AdminGoTOWebsite() throws Exception {
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);

		Adlogin.clickwebsite();
		Thread.sleep(1000);
		
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		
	    driver.switchTo().window(tabs.get(0));
	    
	    driver.close();
	    
	    driver.switchTo().window(tabs.get(1));
	    Thread.sleep(1000);
	    String CurrURL=driver.getCurrentUrl();
	    String ExpURL="https://phptravels.net/";
	    Assert.assertEquals(CurrURL,ExpURL); 
		//Assert.assertTrue(aaa=="https://phptravels.net/"); 
		
		
	}

	@Test(priority=12,description="Verify Admin can delete a booking record if the booking status is Canceled")
	public void AdminDelte() throws Exception {
	
		Adlogin =new AdminLogin(driver);
		Thread.sleep(1000);
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",2);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Adlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Adlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Adlogin.AdminSubmit();
		Thread.sleep(1000);
		Adlogin.ClickBooking();
		Thread.sleep(1000);
		String cancel1=Adlogin.checkcancel1();
		Adlogin.DeleteCancel();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		String cancel2=Adlogin.checkcancel2();
		int CancelCount1=Integer.parseInt(cancel1);
		int CancelCount2=Integer.parseInt(cancel2);
		if(CancelCount2==CancelCount1-1) {
			Assert.assertTrue(true);
		}
		
	}
	
	
}
