package com.qa.phptravels.testscripts;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;



public class Testbase {
WebDriver driver=null;
	
	public static Properties prop = null;
	
	@BeforeTest
	@Parameters("browser")
	public void onSetup(String browserName) throws IOException  {

		System.setProperty("webdriver.http.factory", "jdk-http-client");
		
		//driver = new ChromeDriver();
		if(browserName.equalsIgnoreCase("Chrome")) {
			driver =new ChromeDriver();
		}
		else if(browserName.equalsIgnoreCase("firefox")) {
			
			driver = new FirefoxDriver();
		}
		else if(browserName.equalsIgnoreCase("Edge")) {
			driver = new EdgeDriver();
		}
		
		
		prop = new Properties();
		FileInputStream pFile = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\config.properties");
		
		prop.load(pFile);
		driver.get(prop.getProperty("url"));
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
	}
	@AfterTest
	public void closepage() {
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.quit();
	}
	
}
