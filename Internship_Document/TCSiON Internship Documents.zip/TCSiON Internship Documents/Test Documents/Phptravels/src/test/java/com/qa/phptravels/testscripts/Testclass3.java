package com.qa.phptravels.testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qa.phptravels.pages.SupplierLogin;
import com.qa.phptravels.utilities.ExcelUtility;

public class Testclass3 extends Testbase3{
	
	SupplierLogin Supplogin;
	
	@Test(priority=1,description="Verify Supplier can login with valid email and password")

	public void SupplierLoginverification01() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
		Thread.sleep(1000);
		
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		
		if(SupplierLogin.checkDash()==true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
	Supplogin.clickProfile();
	Thread.sleep(1000);
	Supplogin.clickLogout();
	Thread.sleep(3000);
	}
	
	@Test(priority=2,description="Verify Supplier cannot login with valid email and invalid password")

	public void SupplierLoginverification02() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
		Thread.sleep(1000);
		
		String Logemail = ExcelUtility.getCellData(1, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = ExcelUtility.getCellData(1, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		boolean check=SupplierLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=3,description="Verify Supplier cannot login with invalid email and valid password")

	public void SupplierLoginverification03() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
		Thread.sleep(1000);
		driver.navigate().refresh();
		
		String Logemail = ExcelUtility.getCellData(2, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = ExcelUtility.getCellData(2, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		boolean check=SupplierLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}

	@Test(priority=4,description="Verify Supplier cannot login with invalid email and invalid password")

	public void SupplierLoginverification04() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
		Thread.sleep(1000);
		
		driver.navigate().refresh();
		
		String Logemail = ExcelUtility.getCellData(3, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = ExcelUtility.getCellData(3, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		
		boolean check=SupplierLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=5,description="Verify Supplier cannot login with valid email and null password")

	public void SupplierLoginverification05() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
		Thread.sleep(1000);
		
		driver.navigate().refresh();
		
		String Logemail = ExcelUtility.getCellData(1, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = ""; //ExcelUtility.getCellData(1, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		
		boolean check=SupplierLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=6,description="Verify Supplier cannot login with null email and valid password")

	public void SupplierLoginverification06() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
		Thread.sleep(1000);
		
		driver.navigate().refresh();
		
		String Logemail = ""; //ExcelUtility.getCellData(5, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = ExcelUtility.getCellData(5, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		
		boolean check=SupplierLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=7,description="Verify Supplier cannot login with null email and null password")

	public void SupplierLoginverification07() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
		Thread.sleep(1000);
		driver.navigate().refresh();
		
		String Logemail = ""; // ExcelUtility.getCellData(1, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = "";  //ExcelUtility.getCellData(1, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		Thread.sleep(1000);
		
		boolean check=SupplierLogin.checkResult();
		if(check=true){
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=8,description="Verify Supplier can reset password using the forget password link, Supplier should get a popup message with a textbox to type the email associated with the account to sent the password reset link")

	public void SupplierLoginverification08() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
		Thread.sleep(1000);
		Supplogin.ClickForget();
		Boolean ResetPassword=Supplogin.CheckSignup();
		if(ResetPassword=true) {
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		
	}
	
	@Test(priority=9,description="Verify Supplier can check the dashboard view and check the text 'Sales overview & summary'")

	public void SupplierDashboard() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
			
		driver.navigate().refresh();
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		
		boolean TestDash=Supplogin.checkDashBoard();
		boolean CheckText=Supplogin.checkText();
		
		if(TestDash==true && CheckText==true) {
		Assert.assertTrue(true);
		}
		
	}
	
	@Test(priority=10,description="Verify Supplier can see the revenew breakdown in supplier home page")

	public void SupplierRevenewbrkdwn() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
			
		driver.navigate().refresh();
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		
		//boolean TestDash=Supplogin.checkDashBoard();
		//boolean CheckText=Supplogin.checkText();
		
		boolean checkRev=Supplogin.CheckRevBrkDwn();
		
		Assert.assertTrue(checkRev);
		
		
	}
	
	@Test(priority=11,description="Verify Supplier can change the booking status from pending to confirmed and verify the counts of it '")

	public void SupplierBooking() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
			
		driver.navigate().refresh();
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		
		Supplogin.clickBooking();
		String book="Bookings";
		String error="Page not loaded correctly";
		String checkBook=Supplogin.CheckBooking();
		Assert.assertEquals(checkBook, book, error);
		//Assert.assertEquals(checkBook,"Bookings");
		
		
	}
	
	@Test(priority=12,description="Verify Supplier can see the revenew breakdown in supplier home page")
	public void SupplierRevenew() throws Exception {
	
		Supplogin =new SupplierLogin(driver);
			
		driver.navigate().refresh();
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",3);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Supplogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Supplogin.enterPass(Logpass);
		Thread.sleep(1000);
		Supplogin.SupplierSubmit();
		boolean checkRev=Supplogin.CheckRevBrkDwn();
		
		Assert.assertTrue(checkRev);
		
		
	}
}

