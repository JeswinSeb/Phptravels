package com.qa.phptravels.testscripts;

import java.time.Duration;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qa.phptravels.pages.AgentLogin;
import com.qa.phptravels.utilities.ExcelUtility;

public class Testclass1 extends Testbase1 {
	AgentLogin Agentlogin;
	
	@Test(priority=1,description="Verify customer can login with valid email and password")

	public void AgentLoginverification01() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		//System.out.println(Logemail);
		//System.out.println(Logpass);
	
		Agentlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Agentlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Agentlogin.AgentSubmit();
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
	Agentlogin.ClickAcc();
	Thread.sleep(1000);
	Agentlogin.clickLogout();
	Thread.sleep(3000);
	}
	
	@Test(priority=2,description="Verify customer cannot login with invalid email and valid password")

	public void AgentLoginverification02() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		
		String Logemail = ExcelUtility.getCellData(1, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		String Logpass = ExcelUtility.getCellData(1, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		Agentlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Agentlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Agentlogin.AgentSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(false);
		}
		else 
		{
			Assert.assertTrue(true);
		}
	
	}
	
	@Test(priority=3,description="Verify customer cannot login with valid email and invalid password")

	public void AgentLoginverification03() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		
		String Logemail = ExcelUtility.getCellData(2, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		String Logpass = ExcelUtility.getCellData(2	, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		Agentlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Agentlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Agentlogin.AgentSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(false);
		}
		else 
		{
			Assert.assertTrue(true);
		}
	
	}

	@Test(priority=4,description="Verify customer cannot login with invalid email and invalid password")

	public void AgentLoginverification04() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		
		String Logemail = ExcelUtility.getCellData(3, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		String Logpass = ExcelUtility.getCellData(3, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		Agentlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Agentlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Agentlogin.AgentSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(false);
		}
		else  
		{
			Assert.assertTrue(true);
		}
	
	}
	
	@Test(priority=5,description="Verify customer cannot login with ivalid email and null password")

	public void AgentLoginverification05() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		
		String Logemail = ExcelUtility.getCellData(4, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		String Logpass =""; //ExcelUtility.getCellData(2	, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		//Agentlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Agentlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Agentlogin.AgentSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(false);
		}
		else 
		{
			Assert.assertTrue(true);
		}
	
	}
	
	@Test(priority=6,description="Verify customer cannot login with null email and valid password")

	public void AgentLoginverification06() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		
		String Logemail =""; //ExcelUtility.getCellData(2, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		String Logpass = ExcelUtility.getCellData(5	, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		Agentlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Agentlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Agentlogin.AgentSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("https://phptravels.net/login")) {
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
	}
	@Test(priority=7,description="Verify customer cannot login with null email and null password")

	public void AgentLoginverification07() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		
		String Logemail =""; //ExcelUtility.getCellData(2, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		String Logpass ="";// ExcelUtility.getCellData(2	, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		Agentlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Agentlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Agentlogin.AgentSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("https://phptravels.net/login")) {
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
	}
	
	@Test(priority=8,description="Verify Customer can reset the password using the Reset Password link in login page")

	public void AgentLoginverification08() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		Thread.sleep(1000);
		Agentlogin.ClickReset();
		//Thread.sleep(1000);
		
		boolean check=Agentlogin.CheckReset();
		System.out.println(check);
		if(check=true) {
			Assert.assertTrue(true);
			
		}
		else {
			Assert.assertTrue(false);
		}
	
	}
	
	@Test(priority=9,description="Verify Customer can signup using the signup link in login page")

	public void AgentLoginverification09() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		driver.navigate().refresh();
		Thread.sleep(1000);
		Agentlogin.ClickSignup();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/signup"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
	}

	
	@Test(priority=10,description="Verify Agent can move to my bookings page  from the customer dashboard")

	public void Agent_Bookings() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Agentlogin.clickAccount();
		Thread.sleep(1000);
		Agentlogin.clickCusLog();
		String Logemail =ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		String Logpass =ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",1);
		Agentlogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Agentlogin.enterPass(Logpass);
		Thread.sleep(1000);
		Agentlogin.AgentSubmit();
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Agentlogin.ClickAcc();
		Agentlogin.ClickBookings();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/account/bookings"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	
	@Test(priority=11,description="Verify Agent can move to my Add Funds page  from the customer dashboard")

	public void Agent_AddFunds() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Thread.sleep(1000);
		Agentlogin.ClickAcc();
		Agentlogin.ClickFunds();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/account/add_funds"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	@Test(priority=12,description="Verify Agent can move to profiles page using the my profile link")

	public void Agent_Profile() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Thread.sleep(1000);
		Agentlogin.ClickAcc();
		Agentlogin.ClickProfile();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/account/profile"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	@Test(priority=13,description="Verify customer can logout from account using the logout button in dashboard")

	public void AgentLogout() throws Exception {
	
			
		Agentlogin.ClickAcc();
		Thread.sleep(1000);
		Agentlogin.clickLogout();
		Thread.sleep(3000);
		if(driver.getCurrentUrl().equals("https://phptravels.net/login")) {
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
	}
	
	@Test(priority=14,description="Verify Agent can move to my home page  using home button")

	public void Agent_Home() throws Exception {
	
		Agentlogin =new AgentLogin(driver);		
		Agentlogin.ClickHotel();
		Thread.sleep(1000);
		
		Agentlogin.ClickHome();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	
	@Test(priority=15,description="Verify Agent can move to hotels page using the hotels link")

	public void Agent_Hotels() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		Agentlogin.ClickHotel();
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/hotels"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	
	@Test(priority=16,description="Verify Agent can move to flights page using the flights link")

	public void Agentflights() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
	
		Agentlogin.ClickFlights();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/flights"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	
	@Test(priority=17,description="Verify customer can move to tours page using tours link")

	public void AgentTours() throws Exception {
	
		Agentlogin.ClickTours();
		Thread.sleep(1000);
		if(driver.getCurrentUrl().equals("https://phptravels.net/tours")) {
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
	}

	
	@Test(priority=18,description="Verify Agent can move to visa page using the visa link")

	public void AgentVisa() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
		Agentlogin.ClickVisa();
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/visa"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	
	@Test(priority=19,description="Verify Agent can move to blog page using the blog link")

	public void AgentBlog() throws Exception {
	
		Agentlogin =new AgentLogin(driver);
		Thread.sleep(1000);
	
		Agentlogin.ClickBlog();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/blog"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	
	@Test(priority=20,description="Verify Agent can move to offers page using offers link")

	public void AgentOffers() throws Exception {
		Agentlogin =new AgentLogin(driver);
		Agentlogin.ClickOffers();
		Thread.sleep(1000);
		if(driver.getCurrentUrl().equals("https://phptravels.net/offers")) {
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
	}
	@Test(priority=20,description="Verify Agent can change the currency type from USD to INR in the dashboard")

	public void ChangeCurrency() throws Exception {
		Agentlogin =new AgentLogin(driver);
	
		Agentlogin.ClickCurrency();
		Thread.sleep(1000);
		Agentlogin.ClickINR();
		Thread.sleep(3000);
		
		String inrcheck=Agentlogin.checkINR();
		
		if(inrcheck=="INR") {
			Assert.assertTrue(true);
			
		}
	}

	@Test(priority=21,description="Verify Agent can search hotels by location")

	public void SearchHotel() throws Exception {
		Agentlogin =new AgentLogin(driver);
		Agentlogin.ClickHotel();
		Thread.sleep(1000);
		
		String Location =ExcelUtility.getCellData(0	, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",5);
		Agentlogin.search_hotel();
		Agentlogin.SearchHotel(Location);
		Thread.sleep(1000);
		Agentlogin.search();
		if(driver.getCurrentUrl().contains("https://phptravels.net/")) {
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}		
}
