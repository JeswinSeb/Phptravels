package com.qa.phptravels.testscripts;

import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.qa.phptravels.utilities.ExcelUtility;
import com.qa.phptravels.pages.CustomerLogin;

public class Testclass extends Testbase{
	CustomerLogin Cuslogin;
	
	@Test(priority=1,description="Verify customer can login with valid email and password")
	public void Customerloginverification01() throws Exception {
		
		Cuslogin =new CustomerLogin(driver);
		Thread.sleep(1000); 
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		Cuslogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Cuslogin.enterPass(Logpass);
		Thread.sleep(1000);
		Cuslogin.CustomerSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
		Cuslogin.ClickAcc();
		Thread.sleep(1000);
		Cuslogin.clickLogout();
		Thread.sleep(3000);
	}
	
	@Test(priority=2,description="Verify customer cannot login with invalid email and valid password")

	public void Customerloginverification02() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		Thread.sleep(1000);
		String Logemail = ExcelUtility.getCellData(1, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		String Logpass = ExcelUtility.getCellData(1, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		Cuslogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Cuslogin.enterPass(Logpass);
		Thread.sleep(1000);
		Cuslogin.CustomerSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(false);
		}
		else 
		{
			Assert.assertTrue(true);
		}
	
	}
	
	@Test(priority=3,description="Verify customer cannot login with valid email and invalid password")

	public void Customerloginverification03() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		Thread.sleep(1000);
		String Logemail = ExcelUtility.getCellData(2, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		String Logpass = ExcelUtility.getCellData(2	, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		Cuslogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Cuslogin.enterPass(Logpass);
		Thread.sleep(1000);
		Cuslogin.CustomerSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(false);
		}
		else 
		{
			Assert.assertTrue(true);
		}
	
	}

	@Test(priority=4,description="Verify customer cannot login with invalid email and invalid password")

	public void Customerloginverification04() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		Thread.sleep(1000);
		String Logemail = ExcelUtility.getCellData(3, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		String Logpass = ExcelUtility.getCellData(3, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		Cuslogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Cuslogin.enterPass(Logpass);
		Thread.sleep(1000);
		Cuslogin.CustomerSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(false);
		}
		else 
		{
			Assert.assertTrue(true);
		}
	
	}
	
	@Test(priority=5,description="Verify customer cannot login with ivalid email and null password")

	public void Customerloginverification05() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		String Logemail = ExcelUtility.getCellData(4, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		String Logpass ="";
		Cuslogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Cuslogin.enterPass(Logpass);
		Thread.sleep(1000);
		Cuslogin.CustomerSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(false);
		}
		else 
		{
			Assert.assertTrue(true);
		}
	
	}
	
	@Test(priority=6,description="Verify customer cannot login with null email and valid password")

	public void Customerloginverification06() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		Thread.sleep(1000);
		String Logemail =""; 
		String Logpass = ExcelUtility.getCellData(5	, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		Cuslogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Cuslogin.enterPass(Logpass);
		Thread.sleep(1000);
		Cuslogin.CustomerSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(false);
		}
		else 
		{
			Assert.assertTrue(true);
		}
	
	}
	@Test(priority=7,description="Verify customer cannot login with null email and null password")

	public void Customerloginverification07() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		String Logemail =""; 
		String Logpass ="";
		Cuslogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Cuslogin.enterPass(Logpass);
		Thread.sleep(1000);
		Cuslogin.CustomerSubmit();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().contains("/account/dashboard")) {
			Assert.assertTrue(false);
		}
		else 
		{
			Assert.assertTrue(true);
		}
	
	}
	
	@Test(priority=8,description="Verify Customer can reset the password using the Reset Password link in login page")

	public void Customerloginverification08() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		Thread.sleep(1000);
		Cuslogin.ClickReset();
		Thread.sleep(1000);
		
		boolean check=Cuslogin.CheckReset();
		
		Assert.assertTrue(check);
		Cuslogin.ClickClose();
		
	}	
	
	@Test(priority=9,description="Verify Customer can move to my bookings page  from the customer dashboard")

	public void Customer_Bookings() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		//driver.navigate().to("https://phptravels.net/login");
		String Logemail =ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		String Logpass =ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		Cuslogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Cuslogin.enterPass(Logpass);
		Thread.sleep(1000);
		Cuslogin.CustomerSubmit();
		Thread.sleep(1000);
		if(driver.findElement(By.xpath("//button[@id='cookie_stop']")).isDisplayed()) {
			driver.findElement(By.xpath("//button[@id='cookie_stop']")).click();
		}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		Cuslogin.ClickAcc();
		Cuslogin.ClickBookings();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/account/bookings"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	
	@Test(priority=10,description="Verify Customer can move to my Add Funds page  from the customer dashboard")

	public void Customer_AddFunds() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Thread.sleep(1000);
		Cuslogin.ClickAcc();
		Cuslogin.ClickFunds();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/account/add_funds"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	@Test(priority=11,description="Verify Customer can move to My Profile page using the My Profile link in dashboard")

	public void Customer_Profile() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Thread.sleep(1000);
		Cuslogin.ClickAcc();
		Cuslogin.ClickProfile();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/account/profile"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
	}
	
	@Test(priority=12,description="Verify Customer can see the voucher of a booking")

	public void Customer_Voucher() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Thread.sleep(1000);
		Cuslogin.ClickAcc();
		Cuslogin.ClickBookings();
		Thread.sleep(1000);
		Cuslogin.ClickVoucher();
		Thread.sleep(1000);
		 ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs.get(1));
		
		if(driver.getCurrentUrl().contains("/booking/invoice/"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.close();
		driver.switchTo().window(tabs.get(0));
	}

	@Test(priority=13,description="Verify customer can add funds to his account using paypal option in dashboard")

	public void AddFundToPaypal() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		/*Cuslogin.clickAccount();
		Thread.sleep(1000);
		Cuslogin.clickCusLog();
		String Logemail = ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		String Logpass = ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",0);
		Cuslogin.enterEmail(Logemail);
		Thread.sleep(1000);
		Cuslogin.enterPass(Logpass);
		Thread.sleep(1000);
		Cuslogin.CustomerSubmit();
		Thread.sleep(1000);
		*/
		Cuslogin.cookie();
		Cuslogin.ClickFunds();
		Thread.sleep(1000);
	
		Cuslogin.ClickPaypal();
		Thread.sleep(1000);
		Cuslogin.SendFund();
		Thread.sleep(1000);
		Cuslogin.ClickPayNow();
		Thread.sleep(1000);
		String link1="https://phptravels.net/payment/paypal";
		String link2=driver.getCurrentUrl().toString();
	
			Assert.assertEquals(link1, link2);
			Cuslogin.Moveback();
		//ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		//driver.switchTo().window(tabs.get(1));
		//driver.close();
		//driver.switchTo().window(tabs.get(0));
		
	}
	
	
	@Test(priority=14,description="Verify Customer can update the address in profile")

	public void Customer_Address_Update() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);
		// ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		//    driver.switchTo().window(tabs.get(0));
		Cuslogin.ClickAcc();
		Cuslogin.ClickProfile();
		Thread.sleep(1000);
		Cuslogin.cookie();
		String add1 =ExcelUtility.getCellData(9, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",4);
		String add2= ExcelUtility.getCellData(10	, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx",4);
		Cuslogin.SetAddress1(add1);
		Thread.sleep(1000);
		Cuslogin.SetAddress2(add2);
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Cuslogin.UpdateProfile();

		Thread.sleep(1000);
		if(driver.getCurrentUrl().contains("/profile/success"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		
	}
	
	@Test(priority=15,description="Verify customer can logout from account using the logout button")

	public void CustomerLogout() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);

		
		Cuslogin.ClickAcc();
		Thread.sleep(1000);
		Cuslogin.clickLogout();
		Thread.sleep(3000);
		if(driver.getCurrentUrl().equals("https://phptravels.net/login")) {
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
	}
	

	@Test(priority=16,description="Verify Customer can signup using the signup button in customer login page")
	public void CustomerSignup() throws Exception {
	
		Cuslogin =new CustomerLogin(driver);

		Cuslogin.ClickSignup();
		Thread.sleep(1000);
		
		if(driver.getCurrentUrl().equals("https://phptravels.net/signup"))
				{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
	}
	
	
}
